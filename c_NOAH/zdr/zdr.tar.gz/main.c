/**************************************
 *FILE    :main.c
 *PROJECT :zdr
 *AUTHOR  :
 *CREATED :8/18/2013
***************************************/

int main(int argc, char *argv[])
{
system("/mnt/ProgFS/QtPalmtop/bin/bomberclone");
}
